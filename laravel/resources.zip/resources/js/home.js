
console.log('king')
//slider script